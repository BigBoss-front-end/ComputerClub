<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title><?php echo $__env->yieldContent('title', 'Sonya'); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.scss'); ?>
    <?php echo $__env->yieldContent('styles'); ?>

    <script src="https://cdn.tailwindcss.com"></script>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
</head>
<body>
    
    <div class="bg-dots-lighter bg-gray-900">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html><?php /**PATH D:\OSPanel\domains\sonya\resources\views/layouts/main.blade.php ENDPATH**/ ?>