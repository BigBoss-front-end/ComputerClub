import axios from "axios";
import { UPDATE_COMPUTER_URL } from "../../utils/constants";

import '../../utils/modal';

import '../../utils/content-toggle';

import './components/client';

import './components/computer';

import './components/booking';