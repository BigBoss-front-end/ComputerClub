<div {{$attributes->merge([
    'class' => 'w-10 h-10 cursor-pointer'
])}}>
    {{$slot}}
</div>