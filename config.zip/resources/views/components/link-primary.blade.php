<div class="text-right">
    <a {{$attributes->merge([
        'class' => 'text-gray-900 underline underline-offset-4 hover:no-underline  cursor-pointer ali'
    ])}}>
        {{$slot}}
    </a>
</div>