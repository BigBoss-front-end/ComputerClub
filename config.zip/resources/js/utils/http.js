import axios from "axios";
import iziToast from 'izitoast';

export const $instanse = axios.create()



export const $rest = axios.create()

$rest.interceptors.response.use(response => {
    iziToast.success({
        title: 'Успешно',
        message: response.data.message
    });

    return response;
}, error => {
    console.log(error)
    if(error.response.status == 422) {
        iziToast.warning({
            title: 'Внимание',
            message: 'Ошибка валидации'
        });
    } else if(error.response.status == 500) {
        iziToast.warning({
            title: 'Успешно',
            message: 'Ошибка сервера'
        });
    } else {
        iziToast.error({
            title: 'Ошибка',
            message: error.response.data.message
        });
    }

    return Promise.reject(error);
})