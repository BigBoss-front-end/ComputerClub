$(function() {

})

window.showUserForm = () => {
    $('#user-form').addClass('active')
}

window.hideUserForm = () => {
    $('#user-form').removeClass('active')
}