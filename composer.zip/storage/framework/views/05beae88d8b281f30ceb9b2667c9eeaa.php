<?php
    $computers = \App\Models\Computer::query()->orderBy('sort')->get();
    \App\Http\Services\ComputerService::setStatusesAndClients($computers)::setNearest($computers);
?>


<div data-content data-id="computers" class="active flex-1 border border-gray-500 rounded-sm px-2 py-2">
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4" id="computer-list">
        <?php $__currentLoopData = $computers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $computer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="px-2 py-2 shadow-sm border border-gray-500 rounded-sm aspect-square text-white sortable-ghost cursor-pointer"
                data-sort="<?php echo e($computer->sort); ?>" data-computer-card
                data-id="<?php echo e($computer->id); ?>">
                <div class="outline-none break-all mb-4"
                    oninput="debouncedChangeComputerName(<?php echo e($computer->id); ?>, this.innerHTML)" contenteditable="true">
                    <?php echo e($computer->name); ?></div>
                <div class="mb-2">
                    <span class="text-gray-500">Статус:</span>
                    <span class="text-<?php echo e($computer->color); ?>-700"><?php echo e($computer->status->name); ?></span>

                </div>
                <?php if(!empty($computer->client)): ?>
                    <div class="mb-2">
                        <span class="text-gray-500">Клиент:</span>
                        <span class="text-white"><?php echo e($computer->client->name); ?></span>
                    </div>
                    <div class="mb-2">
                        <span class="text-gray-500">Освободится:</span>
                        <span
                            class="text-white"><?php echo e(\Carbon\Carbon::parse($computer->booking->end_time)->locale('ru')->translatedFormat('d.m H:i')); ?></span>
                    </div>
                <?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalbb660c7d3380b22758129b879204cbaa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb660c7d3380b22758129b879204cbaa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-button','data' => ['onclick' => 'openComputerMenu('.e($computer->id).')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'openComputerMenu('.e($computer->id).')']); ?>Просмотр <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb660c7d3380b22758129b879204cbaa)): ?>
<?php $attributes = $__attributesOriginalbb660c7d3380b22758129b879204cbaa; ?>
<?php unset($__attributesOriginalbb660c7d3380b22758129b879204cbaa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb660c7d3380b22758129b879204cbaa)): ?>
<?php $component = $__componentOriginalbb660c7d3380b22758129b879204cbaa; ?>
<?php unset($__componentOriginalbb660c7d3380b22758129b879204cbaa); ?>
<?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div data-add-computer-button
            class="non-sortable px-2 shadow-sm border border-gray-500 rounded-sm aspect-square flex items-center justify-center text-white hover:text-black hover:bg-white cursor-pointer"
            onclick="addComputer()">+</div>
    </div>
</div>

<script id="computer-card-template" type="text/template">
    <div class="px-2 py-2 shadow-sm border border-gray-500 rounded-sm aspect-square text-white sortable-ghost cursor-pointer"
        onclick="openComputerMenu(<%= computer.id %>)" data-computer-card data-id="<%= computer.id %>">
        <div class="outline-none break-all mb-4"
            oninput="debouncedChangeComputerName(<%= computer.id %>, this.innerHTML)" contenteditable="true">
            <%= computer.name %></div>
        <div class="mb-2">
            <span class="text-gray-500">Статус:</span>
            <span class="text-<%= computer.color %>-700"><%= computer.status.name %></span>

        </div>
        <% if (computer.client) { %>
            <div class="mb-2">
                <span class="text-gray-500">Клиент:</span>
                <span class="text-white"><%= computer.client.name %></span>
            </div>
            <div class="mb-2">
                <span class="text-gray-500">Освободится:</span>
                <span
                    class="text-white"><%= moment(computer.booking.end_time).format('DD.MM HH:mm') %></span>
            </div>
        <% } %>
        <?php if (isset($component)) { $__componentOriginalbb660c7d3380b22758129b879204cbaa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb660c7d3380b22758129b879204cbaa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-button','data' => ['onclick' => 'openComputerMenu(<%= computer.id %>)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'openComputerMenu(<%= computer.id %>)']); ?>Просмотр <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb660c7d3380b22758129b879204cbaa)): ?>
<?php $attributes = $__attributesOriginalbb660c7d3380b22758129b879204cbaa; ?>
<?php unset($__attributesOriginalbb660c7d3380b22758129b879204cbaa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb660c7d3380b22758129b879204cbaa)): ?>
<?php $component = $__componentOriginalbb660c7d3380b22758129b879204cbaa; ?>
<?php unset($__componentOriginalbb660c7d3380b22758129b879204cbaa); ?>
<?php endif; ?>
    </div>
</script>

<?php echo $__env->make('pages.dashboard.components.panel.computer-menu-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('pages.dashboard.components.panel.computer-manage-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('pages.dashboard.components.panel.computer-edit-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\OSPanel\domains\sonya\resources\views/pages/dashboard/components/panel/index.blade.php ENDPATH**/ ?>