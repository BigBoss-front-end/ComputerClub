

<?php $__env->startSection('title'); ?>
    Панель
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/pages/dashboard/script.js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div data-content-wrapper class="h-screen p-2 flex flex-col">
        <div class="flex items-center">
            <div class="text-xl text-white p-2 rounded-sm cursor-pointer [&.active]:bg-gray-700 hover:bg-gray-700 active"
                data-content-nav data-id="computers">Компьютеры</div>
            <div class="text-xl text-white p-2 rounded-sm cursor-pointer [&.active]:bg-gray-700 hover:bg-gray-700"
                data-content-nav data-id="clients">Клиенты</div>
        </div>

        <?php echo $__env->make('pages.dashboard.components.panel.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('pages.dashboard.components.clients.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('pages.dashboard.components.booking.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

    <?php echo $__env->make('pages.dashboard.components.clients.client-add-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('pages.dashboard.components.clients.client-edit-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\sonya\resources\views/pages/dashboard/index.blade.php ENDPATH**/ ?>