<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'px' => 2,
    'py' => 2,
    'bg' => 'gray',
    'id' => '',
    'data' => '',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'px' => 2,
    'py' => 2,
    'bg' => 'gray',
    'id' => '',
    'data' => '',
]); ?>
<?php foreach (array_filter(([
    'px' => 2,
    'py' => 2,
    'bg' => 'gray',
    'id' => '',
    'data' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<form class="submit-prevent-default px-<?php echo e($px); ?> py-<?php echo e($py); ?> bg-<?php echo e($bg); ?>-500" id="<?php echo e($id); ?>" data-form-id="<?php echo e(Str::uuid()); ?>" <?php echo e($data); ?>>
    <?php echo csrf_field(); ?>
    <?php echo e($slot); ?>

</form><?php /**PATH D:\OSPanel\domains\sonya\resources\views/components/form.blade.php ENDPATH**/ ?>