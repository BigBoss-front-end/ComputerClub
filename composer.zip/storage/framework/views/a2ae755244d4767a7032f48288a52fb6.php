<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title><?php echo $__env->yieldContent('title', 'Sonya'); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.scss'); ?>
    <?php echo $__env->yieldContent('styles'); ?>

    <script src="https://cdn.tailwindcss.com"></script>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.scss', 'resources/js/app.js']); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
</head>

<body>
    <div id="app" class="h-screen overflow-auto">
        <nav class="bg-white shadow-sm py-3">
            <div class="container flex itemx-center justify-between mx-auto">
                <a class="" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </a>
                <button id="menu-btn" class="relative group" type="button" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <div class="space-y-2">
                        <div class="h-0.5 w-8 bg-gray-600"></div>
                        <div class="h-0.5 w-8 bg-gray-600"></div>
                        <div class="h-0.5 w-8 bg-gray-600"></div>
                      </div>
                    <div class="hidden group-[.active]:block absolute top-full right-0">
                        <!-- Left Side Of Navbar -->
                        <ul class="navbar-nav me-auto">
    
                        </ul>
    
                        <!-- Right Side Of Navbar -->
                        <ul class="navbar-nav ms-auto">
                            <!-- Authentication Links -->
                            <?php if(auth()->guard()->guest()): ?>
                                <?php if(Route::has('login')): ?>
                                    <li class="bg-white px-2 py-2">
                                        <a class="text-black" href="<?php echo e(route('login')); ?>"><?php echo e(__('Вход')); ?></a>
                                    </li>
                                <?php endif; ?>
    
                                <?php if(Route::has('register')): ?>
                                    <li class="bg-white px-2 py-2">
                                        <a class="text-black" href="<?php echo e(route('register')); ?>"><?php echo e(__('Регистрация')); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php else: ?>
                                <li class="bg-white px-2 py-2">
                                    <a id="navbarDropdown" class="text-black" href="#" role="button"
                                        data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                        <?php echo e(Auth::user()->name); ?>

                                    </a>
    
                                    <div class="bg-white px-2 py-2">
                                        <a class="text-black" href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                        document.getElementById('logout-form').submit();">
                                            <?php echo e(__('Выйти')); ?>

                                        </a>
    
                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </div>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </button>

                
            </div>
        </nav>

        <main class="py-4 bg-dots-lighter bg-gray-900 h-screen">
            <div class="container mx-auto">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>
    </div>

</body>

</html>
<?php /**PATH D:\OSPanel\domains\sonya\resources\views/layouts/main.blade.php ENDPATH**/ ?>